# deploy_example · 部署框架示例

保留电机和 IMU 的 CAN 通信、多线程部署框架。当前仅支持 `--check`，没有具体策略推理代码。

## 目录

```text
deploy_example/
├── CMakeLists.txt            # Linux C++17 构建，链接 libusb_can
├── deploy.sh                 # 唯一入口 ./deploy.sh --check
├── policy/README.md          # 模型和同版本 JSON 的预留位置
├── include/
│   ├── HardwareConfig.h      # CAN 设备、通道、ID、参考角度
│   ├── CheckRunner.h         # 生命周期、共享快照、线程接口
│   ├── RS_motor.h            # 原项目电机协议
│   ├── Hipnuc_IMU.h          # 原项目 IMU SYNC 接口的精简版
│   └── usb_can.h             # SDK 头文件；运行还需系统 libusb_can
└── src/
    ├── main.cpp
    ├── CheckRunner.cpp       # 接收 / 发送 / 部署 / 键盘四个线程
    ├── RS_motor.cpp
    └── Hipnuc_IMU.cpp
```

## 构建与检查

适用 Linux 实机，需 CMake ≥3.16、C++17 编译器及对应 USB2CAN SDK 的 `libusb_can` 库与驱动。压缩包**没有**包含 SDK 动态库或机器人固件。先在 `include/HardwareConfig.h` 核对 `/dev/USB2CAN0`、CAN1 的电机 1–3、CAN2 的电机 4–6、CAN2 的 IMU 0x12、参考角度；再核对该硬件的编码范围及方向（`RS_motor.h`、`CheckRunner.cpp`）。

```bash
./deploy.sh --check
# 或者：
cmake -S . -B build
cmake --build build -j
./build/deploy_example --check
```

`P` 打印 6 个电机和 IMU 的原始反馈及帧龄；`Esc` 退出。Ctrl+C / SIGTERM 也走线程停止、失能电机、关闭设备流程。其他键无动作。需要交互终端；无终端时在打开 CAN 前退出。

## 线程与边界

`main` 完成硬件初始化、零增益命令和退出清理；CAN 接收线程解码反馈并在互斥锁下更新快照；CAN 发送线程按 50 Hz 发 IMU SYNC 和六个零增益 PD 帧；部署线程按 50 Hz 读取快照，预留推理接入位置；键盘线程负责打印与退出。部署线程在 `--check` 下实际运行，但不加载模型、不产生动作。未来接入推理时，还需实现 JSON 观测和动作适配、目标值检查、线程间命令传递及使能门控。

**注意：`--check` 不是纯读取。**它会打开 CAN、使能六个电机、配置 IMU 并持续发送 `Kp=0, Kd=0, FF=0` 的 PD 帧；正常退出时失能电机。零增益不等于断电或机械安全，按本机硬件规程操作。硬件参数来自原案例，未经其他机器人验证。异常断电或强制杀进程时无法保证执行失能清理。

原始项目采用 Apache License 2.0；修改版本保留许可证，见 `LICENSE`。原始 USB2CAN SDK 仅保留了接口头文件，系统库请从设备供应方获取。
