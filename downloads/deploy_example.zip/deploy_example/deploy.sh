#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
if [[ "${1:-}" != "--check" || "$#" -ne 1 ]]; then
  echo "Usage: ./deploy.sh --check" >&2
  exit 2
fi
cmake -S . -B build
cmake --build build -j
exec ./build/deploy_example --check
