#pragma once

#include "HardwareConfig.h"
#include "Hipnuc_IMU.h"
#include "RS_motor.h"

#include <array>
#include <atomic>
#include <chrono>
#include <mutex>
#include <thread>

// Rx -> synchronized snapshot -> deployment loop -> Tx are separate threads.
// The deployment loop has no inference implementation. --check never promotes
// the zero-gain command to motion gains.
class CheckRunner {
public:
    CheckRunner() = default;
    ~CheckRunner();
    CheckRunner(const CheckRunner&) = delete;
    CheckRunner& operator=(const CheckRunner&) = delete;

    void Run();
    void RequestStop() noexcept { running_.store(false); }

private:
    using Clock = std::chrono::steady_clock;
    struct SensorSnapshot {
        std::array<RS_Motor_Struct, HardwareConfig::motor_count> motors{};
        std::array<bool, HardwareConfig::motor_count> motor_received{};
        std::array<Clock::time_point, HardwareConfig::motor_count> motor_time{};
        Hipnuc_IMU_Struct imu{};
        bool quat_received = false;
        bool gyro_received = false;
        Clock::time_point quat_time{};
        Clock::time_point gyro_time{};
    };

    void ReceiveLoop();
    void TransmitLoop();
    void DeploymentLoop();
    void KeyboardLoop();
    void PrintStatus();
    void ZeroGainCommand();
    void EnableMotors();
    void DisableMotors();
    void StopAndClose() noexcept;

    int device_ = -1;
    std::atomic<bool> running_{false};
    std::mutex sensor_mutex_;
    SensorSnapshot sensor_;
    RS_Motor motor_; // Only the transmit/main thread uses its mutable CAN frame.
    Hipnuc_IMU imu_; // Only the transmit/main thread uses its mutable CAN frame.
    std::thread receive_thread_;
    std::thread transmit_thread_;
    std::thread deployment_thread_;
    std::thread keyboard_thread_;
    std::atomic<unsigned long long> deployment_cycles_{0};
};
