#pragma once

#include <array>
#include <cstdint>

// Adapt these values to your robot before connecting hardware.
struct HardwareConfig {
    static constexpr const char* device = "/dev/USB2CAN0";
    static constexpr uint8_t imu_channel = 2;
    static constexpr uint8_t imu_node = 0x12;
    static constexpr int motor_count = 6;
    static constexpr std::array<float, motor_count> default_angles = {
        0.312f, 0.837f, -2.02f, 2.02f, -0.837f, -0.312f};

    static constexpr uint8_t motor_channel(int id) { return id <= 3 ? 1 : 2; }
};
