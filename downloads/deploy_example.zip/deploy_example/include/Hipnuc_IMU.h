#pragma once

#include "usb_can.h"
#include <cstdint>

// Raw IMU data: no calibration or training-coordinate conversion in --check.
struct Hipnuc_IMU_Struct {
    uint8_t IMU_id = 0;
    float quat[4] = {1.f, 0.f, 0.f, 0.f}; // w, x, y, z
    float angular_velocity[3] = {};       // rad/s, raw IMU body axes
};

class Hipnuc_IMU {
public:
    void IMU_Set_SYNC_Mode(int32_t dev, uint8_t channel, uint8_t imu_id);
    void IMU_Send_SYNC(int32_t dev, uint8_t channel);

private:
    FrameInfo tx_msg_{0, STANDARD, 8};
    uint8_t data_[8]{};
};
