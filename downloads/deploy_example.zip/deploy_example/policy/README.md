# Policy 文件夹（占位）

这里预留 TorchScript 模型及同版本 JSON 配置的位置，例如 `model.jit.pt` 和 `model.json`。

当前示例**仅支持 `--check`**：`policy/` 可以保持只有本说明文件；部署线程会定期获取传感器快照，但没有模型加载、观测/动作适配或推理实现，也不会产生运动指令。

未来接入策略时，应在 `src/CheckRunner.cpp` 的 `DeploymentLoop()` 适配观测和推理，另行实现目标值检查、线程间命令传递和使能门控；确认这些环节后，再设计可启动策略的运行模式。
