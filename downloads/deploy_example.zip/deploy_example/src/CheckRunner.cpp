#include "CheckRunner.h"

#include <cerrno>
#include <cmath>
#include <csignal>
#include <iostream>
#include <poll.h>
#include <stdexcept>
#include <termios.h>
#include <unistd.h>

namespace {
volatile std::sig_atomic_t stop_signal = 0;
void handle_signal(int) { stop_signal = 1; }
constexpr float kPi = 3.1415926f;
constexpr auto kPeriod = std::chrono::milliseconds(20); // 50 Hz CAN TX / IMU SYNC
constexpr auto kMotorSpacing = std::chrono::microseconds(300);

int16_t little_i16(const uint8_t* bytes) {
    return static_cast<int16_t>((bytes[1] << 8) | bytes[0]);
}

struct RawTerminal {
    termios old{};
    bool active = false;
    RawTerminal() {
        if (tcgetattr(STDIN_FILENO, &old) != 0) throw std::runtime_error("cannot read terminal mode");
        termios raw = old;
        raw.c_lflag &= ~(ICANON | ECHO);
        if (tcsetattr(STDIN_FILENO, TCSANOW, &raw) != 0)
            throw std::runtime_error("cannot configure terminal");
        active = true;
        tcflush(STDIN_FILENO, TCIFLUSH);
    }
    ~RawTerminal() { if (active) tcsetattr(STDIN_FILENO, TCSANOW, &old); }
};
} // namespace

CheckRunner::~CheckRunner() { StopAndClose(); }

void CheckRunner::Run() {
    // Do all fallible terminal setup before the CAN device is opened.
    RawTerminal terminal;
    stop_signal = 0;
    const auto old_int = std::signal(SIGINT, handle_signal);
    const auto old_term = std::signal(SIGTERM, handle_signal);
    struct RestoreSignals {
        using Handler = void (*)(int);
        Handler prior_int;
        Handler prior_term;
        ~RestoreSignals() { std::signal(SIGINT, prior_int); std::signal(SIGTERM, prior_term); }
    } restore{old_int, old_term};
    device_ = openUSBCAN(HardwareConfig::device);
    if (device_ < 0) throw std::runtime_error("cannot open /dev/USB2CAN0");
    std::cout << "--check: motor enable + zero-gain PD; no inference or motion gains.\n";
    EnableMotors();
    ZeroGainCommand();
    imu_.IMU_Set_SYNC_Mode(device_, HardwareConfig::imu_channel, HardwareConfig::imu_node);

    running_ = true;
    receive_thread_ = std::thread(&CheckRunner::ReceiveLoop, this);
    transmit_thread_ = std::thread(&CheckRunner::TransmitLoop, this);
    deployment_thread_ = std::thread(&CheckRunner::DeploymentLoop, this);
    keyboard_thread_ = std::thread(&CheckRunner::KeyboardLoop, this);
    if (keyboard_thread_.joinable()) keyboard_thread_.join();
    StopAndClose();
}

void CheckRunner::StopAndClose() noexcept {
    running_ = false;
    if (receive_thread_.joinable()) receive_thread_.join();
    if (transmit_thread_.joinable()) transmit_thread_.join();
    if (deployment_thread_.joinable()) deployment_thread_.join();
    if (keyboard_thread_.joinable()) keyboard_thread_.join();
    if (device_ >= 0) {
        DisableMotors();
        closeUSBCAN(device_);
        device_ = -1;
    }
}

void CheckRunner::EnableMotors() {
    for (int id = 1; id <= HardwareConfig::motor_count; ++id) {
        motor_.Motor_Enable(device_, HardwareConfig::motor_channel(id), id);
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
    }
}

void CheckRunner::DisableMotors() {
    for (int id = 1; id <= HardwareConfig::motor_count; ++id) {
        motor_.Motor_Disable(device_, HardwareConfig::motor_channel(id), id);
        std::this_thread::sleep_for(std::chrono::microseconds(500));
    }
}

void CheckRunner::ZeroGainCommand() {
    // Source project's motor protocol expects motor angle = -robot angle.
    // With all gains and feedforward zero, the encoded target cannot request motion.
    Motor_PDControl_Struct zero{};
    for (int id = 1; id <= HardwareConfig::motor_count; ++id) {
        motor_.Motor_PD_Control(device_, HardwareConfig::motor_channel(id), id,
                                &zero, -HardwareConfig::default_angles[id - 1]);
        std::this_thread::sleep_for(kMotorSpacing);
    }
}

void CheckRunner::ReceiveLoop() {
    while (running_) {
        uint8_t channel = 0;
        FrameInfo frame{};
        uint8_t data[8]{};
        // Bounded timeout permits prompt thread shutdown.
        if (readUSBCAN(device_, &channel, &frame, data, 100000) == -1) continue;
        const auto now = Clock::now();
        if (channel == HardwareConfig::imu_channel && frame.frameType == STANDARD &&
            frame.canID == 0x480 + HardwareConfig::imu_node && frame.dataLength == 8) {
            std::lock_guard<std::mutex> lock(sensor_mutex_);
            for (int i = 0; i < 4; ++i)
                sensor_.imu.quat[i] = little_i16(data + i * 2) / 10000.f;
            sensor_.imu.IMU_id = HardwareConfig::imu_node;
            sensor_.quat_received = true;
            sensor_.quat_time = now;
        } else if (channel == HardwareConfig::imu_channel && frame.frameType == STANDARD &&
                   frame.canID == 0x280 + HardwareConfig::imu_node && frame.dataLength == 6) {
            std::lock_guard<std::mutex> lock(sensor_mutex_);
            for (int i = 0; i < 3; ++i)
                sensor_.imu.angular_velocity[i] = little_i16(data + i * 2) * (kPi / 1800.f);
            sensor_.gyro_received = true;
            sensor_.gyro_time = now;
        } else if (frame.frameType == EXTENDED && frame.dataLength == 8) {
            const int id = (frame.canID >> 8) & 0xff;
            if (id < 1 || id > HardwareConfig::motor_count ||
                channel != HardwareConfig::motor_channel(id)) continue;
            const int mode = (frame.canID >> 24) & 0x1f;
            if (mode != 0x02) continue;
            std::lock_guard<std::mutex> lock(sensor_mutex_);
            auto& motor = sensor_.motors[id - 1];
            motor.master_id = frame.canID & 0xff;
            motor.motor_id = id;
            motor.fault_message = (frame.canID >> 16) & 0x3f;
            motor.motor_state = (frame.canID >> 22) & 0x03;
            motor.mode = mode;
            motor.current_position = (data[0] << 8) | data[1];
            motor.current_speed = (data[2] << 8) | data[3];
            motor.current_torque = (data[4] << 8) | data[5];
            motor.current_temp = (data[6] << 8) | data[7];
            motor.current_position_f = -uint_to_float(motor.current_position, P_MIN, P_MAX, 16);
            motor.current_speed_f = -uint_to_float(motor.current_speed, V_MIN, V_MAX, 16);
            motor.current_torque_f = -uint_to_float(motor.current_torque, T_MIN, T_MAX, 16);
            motor.current_temp_f = motor.current_temp / 10.f;
            sensor_.motor_received[id - 1] = true;
            sensor_.motor_time[id - 1] = now;
        }
    }
}

void CheckRunner::TransmitLoop() {
    auto next = Clock::now();
    while (running_) {
        imu_.IMU_Send_SYNC(device_, HardwareConfig::imu_channel);
        ZeroGainCommand();
        next += kPeriod;
        if (next < Clock::now()) next = Clock::now();
        std::this_thread::sleep_until(next);
    }
}

void CheckRunner::DeploymentLoop() {
    auto next = Clock::now();
    while (running_) {
        SensorSnapshot snapshot;
        {
            std::lock_guard<std::mutex> lock(sensor_mutex_);
            snapshot = sensor_;
        }
        // Inference integration point: adapt this snapshot using the matching
        // model + JSON in policy/, then validate targets before sharing them
        // with the transmit thread. The example intentionally has no adapter.
        // In --check, no policy output is produced or sent to motors.
        (void)snapshot;
        ++deployment_cycles_;
        next += kPeriod;
        if (next < Clock::now()) next = Clock::now();
        std::this_thread::sleep_until(next);
    }
}

void CheckRunner::KeyboardLoop() {
    std::cout << "[P] raw motor / IMU feedback   [Esc] disable motors and exit\n";
    while (running_) {
        if (stop_signal) break;
        pollfd fd{STDIN_FILENO, POLLIN, 0};
        const int ready = poll(&fd, 1, 100);
        if (ready < 0 && errno == EINTR) continue;
        if (ready < 0 || (ready > 0 && !(fd.revents & POLLIN))) break;
        if (!ready) continue;
        char key = 0;
        if (read(STDIN_FILENO, &key, 1) != 1) break;
        if (key == 27) break;
        if (key == 'p' || key == 'P') PrintStatus();
    }
    running_ = false;
}

void CheckRunner::PrintStatus() {
    SensorSnapshot snapshot;
    {
        std::lock_guard<std::mutex> lock(sensor_mutex_);
        snapshot = sensor_;
    }
    const auto now = Clock::now();
    const auto age_ms = [now](Clock::time_point time) {
        return std::chrono::duration<float, std::milli>(now - time).count();
    };
    std::cout << "\n[CHECK] zero-gain PD; policy and pose alignment disabled"
              << "; deployment cycles=" << deployment_cycles_.load() << '\n';
    if (snapshot.quat_received) {
        std::cout << "  IMU raw q(wxyz)=[";
        for (int i = 0; i < 4; ++i) std::cout << (i ? ", " : "") << snapshot.imu.quat[i];
        std::cout << "] age=" << age_ms(snapshot.quat_time) << " ms\n";
    } else std::cout << "  IMU quaternion: no frame received\n";
    if (snapshot.gyro_received) {
        std::cout << "  IMU raw gyro(rad/s)=[";
        for (int i = 0; i < 3; ++i) std::cout << (i ? ", " : "") << snapshot.imu.angular_velocity[i];
        std::cout << "] age=" << age_ms(snapshot.gyro_time) << " ms\n";
    } else std::cout << "  IMU gyro: no frame received\n";
    for (int i = 0; i < HardwareConfig::motor_count; ++i) {
        if (!snapshot.motor_received[i]) {
            std::cout << "  motor " << i + 1 << ": no feedback received\n";
            continue;
        }
        const auto& motor = snapshot.motors[i];
        std::cout << "  motor " << i + 1 << ": pos=" << motor.current_position_f
                  << " rad vel=" << motor.current_speed_f
                  << " rad/s offset_from_default="
                  << motor.current_position_f - HardwareConfig::default_angles[i]
                  << " rad mode=" << static_cast<int>(motor.mode)
                  << " fault=" << static_cast<int>(motor.fault_message)
                  << " age=" << age_ms(snapshot.motor_time[i]) << " ms\n";
    }
}
