#include "Hipnuc_IMU.h"

#include <chrono>
#include <thread>

void Hipnuc_IMU::IMU_Set_SYNC_Mode(int32_t dev, uint8_t channel, uint8_t imu_id) {
    tx_msg_.canID = 0x600 | imu_id;
    tx_msg_.dataLength = 8;
    // CANopen 0x1803.2: TPDO4 quaternion; 0x1801.2: TPDO2 gyro.
    data_[0] = 0x2f;
    data_[1] = 0x03;
    data_[2] = 0x18;
    data_[3] = 0x02;
    data_[4] = 0x01;
    sendUSBCAN(dev, channel, &tx_msg_, data_);
    std::this_thread::sleep_for(std::chrono::milliseconds(100));
    data_[1] = 0x01;
    sendUSBCAN(dev, channel, &tx_msg_, data_);
}

void Hipnuc_IMU::IMU_Send_SYNC(int32_t dev, uint8_t channel) {
    tx_msg_.canID = 0x80;
    tx_msg_.dataLength = 0;
    sendUSBCAN(dev, channel, &tx_msg_, data_);
}
