#include "CheckRunner.h"

#include <exception>
#include <iostream>
#include <string>
#include <unistd.h>

int main(int argc, char** argv) {
    if (argc != 2 || std::string(argv[1]) != "--check") {
        std::cerr << "Usage: deploy_example --check\n";
        return 2;
    }
    if (!isatty(STDIN_FILENO)) {
        std::cerr << "--check requires an interactive terminal. CAN was not opened.\n";
        return 2;
    }
    try {
        CheckRunner runner;
        runner.Run();
    } catch (const std::exception& error) {
        std::cerr << "--check failed: " << error.what() << '\n';
        return 1;
    }
    return 0;
}
